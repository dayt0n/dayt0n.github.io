#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
int main()
{
 srand(time(NULL));
 unsigned seed = rand() % 1024;
 int r;
 srand(seed);
 r=rand();
 sleep(1);
 printf("%d",r);
 putchar('\n');
 return 0;
}